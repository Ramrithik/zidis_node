/*
 *----------------------------------------------------------------------
 *    micro T-Kernel 3.00.08
 *
 *    Copyright (C) 2006-2026 by Ken Sakamura.
 *    This software is distributed under the T-License 2.2.
 *----------------------------------------------------------------------
 *
 *    Released by TRON Forum(http://www.tron.org) at 2026/07.
 *
 *----------------------------------------------------------------------
 */

/*
 *	machine.h
 *	Machine type definition 
 */

#ifndef __SYS_MACHINE_H__
#define __SYS_MACHINE_H__

/* ===== System dependencies definitions ================================ */

#define CPU_CORE_ARMV8M 1
#define TARGET_DIR cpu/core/armv8m
#define Csym(sym) sym

#define INTPRI_BITWIDTH 4
#define INTPRI_MAX_EXTINT_PRI 1

#define N_SYSVEC 16
#define INTPRI_SVC 0
#define INTPRI_PENDSV 15
#define INTPRI_SYSTICK 1
#define INTERNAL_RAM_START 0x20000000
#define INTERNAL_RAM_END 0x20044000
#define EXCTBL_ALIGN 2048
#define NUM_COPROCESSOR 1

#ifdef _IOTE_M367_


#include "sysdepend/iote_m367/machine.h"
#define Csym(sym) sym
#endif

#ifdef _IOTE_STM32L4_
#include "sysdepend/iote_stm32l4/machine.h"
#define Csym(sym) sym
#endif

#ifdef _IOTE_RX231_
#include "sysdepend/iote_rx231/machine.h"
#define Csym(sym) _##sym
#endif

#ifdef _IOTE_RZA2M_
#include "sysdepend/iote_rza2m/machine.h"
#define Csym(sym) sym
#endif

#ifdef _STM32_NUCLEO_N657_EXTSEC_
#include "sysdepend/nucleo_stm32n6/machine.h"
#define Csym(sym) sym
#define ADD_PREFIX_MAIN_FUNC		(1)
#endif

#ifdef _RA_EK_RA8M1_EXTSEC_
#include "sysdepend/ek_ra8m1/machine.h"
#define Csym(sym) sym
#define ADD_PREFIX_MAIN_FUNC		(1)
#endif

/* ===== C compiler dependencies definitions ============================= */

#ifdef __GNUC__

#define Inline static __inline__
#define Asm __asm__ volatile
#define Noinit(decl) decl __attribute__((section(".noinit")))
#define	Section(decl,name) decl __attribute__((section(#name)))
#define WEAK_FUNC __attribute__((weak))

#define _VECTOR_ENTRY(name) .word name
#define _WEAK_ENTRY(name) .weak name

#endif /* __GNUC__ */

#endif /* __SYS_MACHINE_H__ */
