Core/Src/zidis_core/seismic_gen.o: ../Core/Src/zidis_core/seismic_gen.c \
 ../Core/Inc/zidis_core/seismic_gen.h ../Core/Inc/zidis_core/config.h
../Core/Inc/zidis_core/seismic_gen.h:
../Core/Inc/zidis_core/config.h:
